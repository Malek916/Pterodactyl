# Pterodactyl
I created these eggs and yolks because I started using processors with ARM architecture, but most of the games and software that Pterodactyl Panel ran with the official eggs and yolks did not support ARM but rather AMD so I based on the eggs. and original buds and thanks to a bit of knowledge that I have I managed to create this incredible collection compatible with ARM and AMD that I will update as I go.

# Eggs and Yolks
* [`egg-mta.json`](/eggs/egg-mta.json) — [`Multi Theft Auto`](https://multitheftauto.com)
	* `ghcr.io/daniscript18/yolks:mta`
	
* [`egg-samp.json`](/eggs/egg-samp.json) — [`San Andreas Multiplayer`](https://sa-mp.com)
	* `ghcr.io/daniscript18/yolks:samp`
	
* [`egg-terraria.json`](/eggs/egg-terraria.json) — [`Terraria`](https://terraria.org)
	* `ghcr.io/daniscript18/yolks:terraria`